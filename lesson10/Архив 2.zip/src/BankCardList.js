import * as React from 'react';
import BankCard from './bankCard';


const BankCardList = props=>{
    const{bankCard}=props;
    return(
        <div>
            {bankCard.map(cardItem=><BankCard key={cardItem.number}{...cardItem}/>)}
        </div>
    )
}

export default BankCardList;