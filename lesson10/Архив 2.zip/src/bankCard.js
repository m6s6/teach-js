import * as React from 'react';
import Bank from './Bank';
import Owner from './Owner';

class BankCard extends React.Component{
    constructor(props){
        super(props);
        this.state={
            nameButton:'показать',
            show: true
        };
        this.showBalance= this.showBalance.bind(this)

    }
    showBalance(){
        this.setState({
            show:!this.state.show,
            nameButton:this.state.show?"скрыть":'показать'
        })
    }
    render(){
        return(

            <div className = "bankCard">
                <Bank {...this.props.bank}/>
                <div>
                    Номер карты: **** **** **** {this.props.number}
                    
                </div>
                <div>
                    Баланс: {this.state.show?"*******":this.props.balance} руб. 
                    <button onClick={this.showBalance}>{this.state.nameButton}</button>
                </div>
                <Owner {...this.props.owner}/>
            </div>
        )
    }
}

export default BankCard;