import * as React from 'react';
import {useState, useEffect} from "react";
import ListTasks from './components/ListTasks';
import NewFormTaskList from './components/NewFormTaskList';
/**
 * Статусы могут быть:
 *-todo
 *-progress
 *-complete 
 *
 */

const App = props=>{
    const [tasks, updateTasks]=useState([
        {
            id:1,
            name:"Сделать первый проект",
            deadline:'2020-06-15',
            description:'Первый проект по теме React',
            status: 'todo'
        },
        {
            id:2,
            name:"Прийти на занятие",
            deadline:'2020-05-25',
            description:'Первый проект по теме React',
            status: 'progress'
        }
    ]);
    const addNewTask = taskName =>{
        const newTask = {
            id: Math.floor(Math.random()*9999999),
            name:taskName,
            deadline:null,
            description:null,
            status:'todo'
        }
        console.log(newTask);
        updateTasks([...tasks,newTask]);

    }
    const updateStatusTask=(newStatus, id)=>{
        console.log('Вызов из App', newStatus, id);
        const newTasks = [...tasks];
        for(const task of  newTasks){
            if(task.id===id){
                task.status = newStatus;
                break;
            }
        }
        updateTasks(newTasks);
    }
    return(
        <>
            <header>
                <h1>Список задач</h1>
            </header>
            <NewFormTaskList addNewTask={addNewTask}/>
            <ListTasks tasks={tasks} updateStatusTask={updateStatusTask}/>
        </>
    )
}

export default App;