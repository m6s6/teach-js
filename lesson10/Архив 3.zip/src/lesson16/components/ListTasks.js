import * as React from 'react';
import {useState, useEffect} from "react";
import SubListTask from './SubListTask';

const ListTasks =props=>{
    const todoList = props.tasks.filter(task=>task.status==='todo');
    const progressList = props.tasks.filter(task=>task.status==='progress');
    const completeList = props.tasks.filter(task=>task.status==='complete');
    console.log(todoList, progressList,completeList);
    return(
        <div className="lists">
            <SubListTask name="todo" tasks={todoList}  updateStatusTask={props.updateStatusTask}/>
            <SubListTask name="progress" tasks={progressList} updateStatusTask={props.updateStatusTask}/>
            <SubListTask name="complete" tasks={completeList} updateStatusTask={props.updateStatusTask}/>

        </div>
    )
}


export default ListTasks;