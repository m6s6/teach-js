import * as React from 'react';
import SubListTasksItem from './SubListTasksItem';

const SubListTask =props=>{
    return(
        <div className="list-item">
            <h2>{props.name} ({props.tasks.length})</h2>
            <div className="list-item-box">
                {/**Здесь будут выводится мои карточки */}
                {props.tasks.map(taskItem=><SubListTasksItem key={taskItem.id} {...taskItem} updateStatusTask={props.updateStatusTask}/>)}
            </div>
        </div>
    )
}

export default SubListTask;