import * as React from 'react';

const SubListTasksItem =props=>{
    const handleChangeStatus=newStatus=>{
        console.log(newStatus, props.id);
        props.updateStatusTask(newStatus,props.id)
    }
    return(
        <div className="list=item-box-item ">
            <div className="list=item-box-item-name">{props.name}</div>
            <button onClick={(e)=>handleChangeStatus("todo")} >todo</button>
            <button onClick={(e)=>handleChangeStatus("progress")}>progress</button>
            <button onClick={(e)=>handleChangeStatus("complete")}>complete</button>
            
        </div>
    )
}

export default SubListTasksItem;