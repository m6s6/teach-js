const initialState = [
    {
        text:"Важная задача",
        date:'2020-04-15',
        taskId:1,
        id:1
    }
]; 

const commentsReducer = (state = initialState, action)=>{
    switch (action.type){
        case 'ADD_COMMENT':
            return [...state,action.comment];
        case 'DELETE_COMMENT':
            return state.filter(comment=>comment.id!==action.id);
        default:
            return state;
    }
}

export {commentsReducer};