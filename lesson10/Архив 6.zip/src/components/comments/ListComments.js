import * as React from 'react';
import ListCommentsItem from './ListCommentsItem';
import EditComment from './EditComment';

const ListComments = props=>{

    return(
        <div className='comments '>
            <ul>
                {props.comments.map(comment=><ListCommentsItem handleDeletComment={props.handleDeletComment} key={comment.id} {...comment}/>)}
            </ul>
            <EditComment addTextNewComment={props.addTextNewComment} />
        </div>
    )
}

export default ListComments;