import * as React from 'react';

const ListCommentsItem = props=>{

    return(
        <li>
            {props.text}<span>({props.date})</span>
            <button onClick={e=>props.handleDeletComment(props.id)}>удалить</button>
        </li>
    )
}

export default ListCommentsItem;