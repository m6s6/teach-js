import * as React from 'react';
import {useState, useEffect} from "react";
import SubListTask from './SubListTask';

const ListTasks =props=>{
    const todoList = props.tasks.filter(task=>task.status==='todo');
    const progressList = props.tasks.filter(task=>task.status==='progress');
    const completeList = props.tasks.filter(task=>task.status==='complete');

    const todoListComments = props.comments.filter(comment=>todoList.map(task=>task.id).includes(comment.taskId));
    const progressListComments = props.comments.filter(comment=>progressList.map(task=>task.id).includes(comment.taskId));
    const completeListComments = props.comments.filter(comment=>completeList.map(task=>task.id).includes(comment.taskId));
    return(
        <div className="lists">
            <SubListTask name="todo" addNewComment={props.addNewComment} handleDeletComment={props.handleDeletComment} comments={todoListComments} tasks={todoList} handleChangeTask={props.handleChangeTask}  handleDeletTask={props.handleDeletTask} addNewTask={props.addNewTask} updateStatusTask={props.updateStatusTask}/>
            <SubListTask name="progress" addNewComment={props.addNewComment} handleDeletComment={props.handleDeletComment} comments={progressListComments} tasks={progressList} handleChangeTask={props.handleChangeTask} handleDeletTask={props.handleDeletTask} addNewTask={props.addNewTask} updateStatusTask={props.updateStatusTask}/>
            <SubListTask name="complete" addNewComment={props.addNewComment} handleDeletComment={props.handleDeletComment} comments={completeListComments} tasks={completeList} handleChangeTask={props.handleChangeTask} handleDeletTask={props.handleDeletTask} addNewTask={props.addNewTask} updateStatusTask={props.updateStatusTask}/>

        </div>
    )
}


export default ListTasks;