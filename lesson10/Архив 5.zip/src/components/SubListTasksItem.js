import * as React from 'react';
import {useState} from 'react';
import EditTask from './EditTask';

const SubListTasksItem =props=>{
    const handleChangeStatus=newStatus=>{
        console.log(newStatus, props.id);
        props.updateStatusTask(newStatus,props.id)
    }
    const [variable, changeVariable]= useState(false)

    const handleClickName= ()=>{
        changeVariable(!variable);
    }

    const changeTask=taskName=>{
        props.handleChangeTask(props.id, taskName)
        changeVariable(!variable);
    }

    return(
        <div className="list=item-box-item ">
            
                {
                    !variable
                        ?<div onClick={handleClickName} className="list=item-box-item-name">{props.name}</div>
                        :<EditTask changeTask={changeTask} valueText={props.name}/>
                }
            
          
            <button onClick={(e)=>handleChangeStatus("todo")} >todo</button>
            <button onClick={(e)=>handleChangeStatus("progress")}>progress</button>
            <button onClick={(e)=>handleChangeStatus("complete")}>complete</button>
            <button onClick={(e)=>props.handleDeletTask(props.id)}>удалить</button>
            
        </div>
    )
}

export default SubListTasksItem;