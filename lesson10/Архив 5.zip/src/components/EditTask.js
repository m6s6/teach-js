import * as React from 'react';
import { taskReducer } from '../store/tasks/reducers';
import {useState} from 'react';


const EditTask=props=>{
    const [inputValue,changeInputValue]=useState(props.valueText)
    const handleChangeInputValue=e=>{
        changeInputValue(e.target.value)
    }
    const handleSubmitForm=e=>{
        e.preventDefault();
        props.changeTask(inputValue)
    }
 
    return(
        <form onSubmit={handleSubmitForm}>
            <input onChange={handleChangeInputValue} type="text" name="task" value={inputValue}></input>
            <button type='submit'>редактировать</button>
        </form>
    )
}

export default EditTask;