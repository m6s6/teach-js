import * as React from 'react';
import {useState, useEffect} from "react";
import ListTasks from './components/ListTasks';
import NewFormTaskList from './components/NewFormTaskList';
import {connect} from 'react-redux';
import {addTask,editTask,deleteTask,changeNameTask} from './store/tasks/actions';
/**
 * Статусы могут быть:
 *-todo
 *-progress
 *-complete 
 *
 */

const App = props=>{
    const [tasks, updateTasks]=useState([
        {
            id:1,
            name:"Сделать первый проект",
            deadline:'2020-06-15',
            description:'Первый проект по теме React',
            status: 'todo'
        },
        {
            id:2,
            name:"Прийти на занятие",
            deadline:'2020-05-25',
            description:'Первый проект по теме React',
            status: 'progress'
        }
    ]);
    const addNewTask = taskName =>{
       
        
        const newTaskData = {
            id: Math.floor(Math.random()*9999999),
            name:taskName.name,
            deadline:null,
            description:null,
            status:taskName.status
        }
      
        // updateTasks([...tasks,newTask]);
        props.addTask(newTaskData)
    }
    const updateStatusTask=(newStatus, id)=>{
        props.editTask(newStatus, id);


        // const newTasks = [...tasks];
        // for(const task of  newTasks){
        //     if(task.id===id){
        //         task.status = newStatus;
        //         break;
        //     }
        // }
        // updateTasks(newTasks);
    }
    const handleChangeTask=(id,newName)=>{
        console.log('APP:',id,newName);
        props.changeNameTask(newName, id)
    }  
    const handleDeletTask = id =>{
            props.deleteTask(id);
            console.log('запрос на удаление', id)
    }
    return(
        <>
            <header>
                <h1>Список задач</h1>
            </header>
            {/* <NewFormTaskList addNewTask={addNewTask}/> */}
            <ListTasks tasks={props.tasks} handleChangeTask={handleChangeTask} handleDeletTask={handleDeletTask} addNewTask={addNewTask} updateStatusTask={updateStatusTask}/>
        </>
    )
}

const mapStateToProps = state => ({
    tasks: state.tasks
});
export default connect(mapStateToProps, {addTask, editTask,deleteTask,changeNameTask})(App);