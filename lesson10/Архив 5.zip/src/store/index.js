import {combineReducers, createStore} from 'redux';
import {taskReducer} from './tasks/reducers';

const rootReducer = combineReducers({
    tasks:taskReducer
});

const configurationStore = ()=>{
    const store = createStore(rootReducer);

    return store;
}

export default configurationStore;