const addTask = newTask =>{
    return{
        type:'ADD_TASK',
        task: {...newTask}
    }
}

const editTask = (newStatus, id) =>{
    return{
        type: 'EDIT_TASK',
        newStatus: newStatus,
        id:id
    }
}

const changeNameTask = (newName, id) =>{
    return{
        type: 'CHANGE_TASK',
        newName: newName,
        id:id
    }
}

const deleteTask = id =>{
    return{
        type:"DELETE_TASK",
        id: id
    }
}
// const newTask = newTaskData =>{
//     return{
//         type:"NEW_TASK",
//         task:{...newTask}
//     }
// }

export {addTask, editTask, deleteTask,changeNameTask};