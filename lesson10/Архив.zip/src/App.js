import * as React from 'react';
import User from './User';
import Book from './Book';
import Course from './Course';
import BankCard from './bankCard';

class App extends React.Component{
    constructor(props){
        super(props);
        this.state ={
            // message:"Привет, Мир! ",
            // count: 0,
            // book:null,
            // course:{
            //     name:"Программирование",
            //     longTime:3,
            //     price:75000,
            //     teacher:{
            //         name: "Анатолий",
            //         surname: "Кодин",
            //         longTimeWorking: 4
            //     },
            //     school:{
            //         name:"Авиаторов",
            //         address:"г.Москва, ул. Барикадная",
            //         site:"school.ru"
            //     }

            // },
            bankCard:{
                number: 4545,
                balance: 15000000,
                owner:{
                    name:"Артур",
                    surname:'Косточкин',
                    email:"artur@mail.ru"
                },
                bank:{
                    name:"Tinkoff",
                    beck: 67235769,
                    logo:'./image/tinkoff.jpg'
                }
            }
            

        }
        // setInterval(() => {
        //     this.setState({count:this.state.count+1});
        //     this.setState({book:{...this.state.book,price:this.state.book.price+1}})
        // }, 1000);
    }
    // componentDidMount(){
    //     fetch('/data.json')
    //         .then(result=>result.json())
    //         .then(data=>{
    //             this.setState({book:{...data}})
    //         })
    // }
    render(){
        console.log('вызов рендер');
        return(
            <>
                {/* <div>{this.state.message}</div>
            <div>Счетчик: {this.state.count}</div>
                <User name="Boris" age={29} skill="Программист"/>
                <User name="Александр Сергеевич Пушкин" age={33} skill="Поэт"/>
                {
                    this.state.book===null
                    ?<div>Загрузка данных....</div>
                    :<Book {...this.state.book}/>
                }
                
                {/* <Course name={this.state.course.name} longTime={this.state.course.longTime} price={this.state.course.price} nameTeacher={this.state.course.teacher.name+" "+this.state.course.teacher.surname}/> */}
                {/*<Course {...this.state.course}/> */}

                <BankCard {...this.state.bankCard}/>
            </>
        )
    }
}


export default App;