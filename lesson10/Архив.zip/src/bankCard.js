import * as React from 'react';
import Bank from './Bank';
import Owner from './Owner';

class BankCard extends React.Component{
    render(){
        return(

            <div className = "bankCard">
                <Bank {...this.props.bank}/>
                <div>Номер карты: **** **** **** {this.props.number}</div>
                <div>Баланс: {this.props.balance} руб.</div>
                <Owner {...this.props.owner}/>
            </div>
        )
    }
}

export default BankCard;